"""
This file is part of nand2tetris, as taught in The Hebrew University, and
was written by Aviv Yaish. It is an extension to the specifications given
[here](https://www.nand2tetris.org) (Shimon Schocken and Noam Nisan, 2017),
as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0
Unported [License](https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing
from os import write


class CodeWriter:
    """Translates VM commands into Hack assembly code."""

    def __init__(self, output_stream: typing.TextIO) -> None:
        """Initializes the CodeWriter.

        Args:
            output_stream (typing.TextIO): output stream.
        """
        self.output_stream = output_stream
        self.current_file = ""
        self.arithmetic_label_counter = 0
        self.current_function = ""
        self.return_address_counter = 0

    def set_file_name(self, filename: str) -> None:
        """Informs the code writer that the translation of a new VM file is
        started.

        Args:
            filename (str): The name of the VM file.
        """
        # Your code goes here!
        # This function is useful when translating code that handles the
        # static segment. For example, in order to prevent collisions between two
        # .vm files which push/pop to the static segment, one can use the current
        # file's name in the assembly variable's name and thus differentiate between
        # static variables belonging to different files.
        # To avoid problems with Linux/Windows/macOS differences with regards
        # to filenames and paths, you are advised to parse the filename in
        # the function "translate_file" in Main.py using python's os library,
        # For example, using code similar to:
        # input_filename, input_extension = os.path.splitext(os.path.basename(input_file.name))
        self.current_file = filename.split(".")[0]

    def write_arithmetic(self, command: str) -> None:
        """Writes assembly code that is the translation of the given
        arithmetic command. For the commands eq, lt, gt, you should correctly
        compare between all numbers our computer supports, and we define the
        value "true" to be -1, and "false" to be 0.

        Args:
            command (str): an arithmetic command.
        """
        valid_arithmetic_commands = {
            "add", "sub", "neg", "eq", "gt", "lt", "and", "or", "not",
            "shiftleft", "shiftright"}

        if command not in valid_arithmetic_commands:
            raise ValueError(f"invalid arithmetic command: {command}")

        self.write_comment(command)

        if command in {"add", "sub"}:
            if command == "add":
                comp_command = "M+D"
            else:
                comp_command = "M-D"

            self.output_stream.write(
                "\t@SP\n"     
                "\tAM=M-1\n"  # SP--; A=SP
                "\tD=M\n"     # D = *SP
                "\tA=A-1\n"   # A = SP - 1
                f"\tM={comp_command}\n"
            )

        if command == "neg":
            self.output_stream.write(
                "\t@SP\n"
                "\tA=M-1\n"
                "\tM=-M\n"
            )

        if command in {"and", "or"}:
            if command == "and":
                comp_command = "D&M"
            else:
                comp_command = "D|M"

            self.output_stream.write(
                "\t@SP\n"     
                "\tAM=M-1\n"  # SP--; A=SP
                "\tD=M\n"     # D = *SP
                "\tA=A-1\n"   # A = SP - 1
                f"\tM={comp_command}\n"
            )

        if command == "not":
            self.output_stream.write(
                "\t@SP\n"
                "\tA=M-1\n"
                "\tM=!M\n"
            )
        if command == "shiftleft":
            self.output_stream.write(
                "\t@SP\n"
                "\tA=M-1\n"
                "\tM=M<<\n"
            )
        if command == "shiftright":
            self.output_stream.write(
                "\t@SP\n"
                "\tA=M-1\n"
                "\tM=M>>\n"
            )

        if command in {"eq", "gt", "lt"}:
            # read arguments from stack to R13 and R14
            self.output_stream.write(
                "\t@SP\n"
                "\tAM=M-1\n"   # SP--; A=SP
                "\tD=M\n"      # D = *SP (arg2)
                "\tA=A-1\n"    # A = SP - 1
                "\tD=M-D\n"    # D = arg1-arg2
            )

            if command == "eq":
                jump_command = "JNE"
            elif command == "gt":
                jump_command = "JLE"
            else:
                jump_command = "JGE"

            # push to stack -1 (true) or 0 (false)
            self.output_stream.write(
                f"\t@{self.current_function}$FALSE.{self.arithmetic_label_counter}\n"
                f"\tD;{jump_command}\n"   # if condition is false jump to FALSE
                "\t@SP\n"
                "\tA=M-1\n"               # A = SP - 1
                "\tM=-1\n"                # push true(-1) to stack
                f"\t@{self.current_function}$END.{self.arithmetic_label_counter}\n"
                "\t0;JMP\n"               # jump to END
                f"({self.current_function}$FALSE.{self.arithmetic_label_counter})\n"
                "\t@SP\n"
                "\tA=M-1\n"               # A = SP - 1
                "\tM=0\n"                # push false(0) to stack
                f"({self.current_function}$END.{self.arithmetic_label_counter})\n"
            )
            self.arithmetic_label_counter += 1

    def write_push_pop(self, command: str, segment: str, index: int) -> None:
        """Writes assembly code that is the translation of the given
        command, where command is either C_PUSH or C_POP.

        Args:
            command (str): "C_PUSH" or "C_POP".
            segment (str): the memory segment to operate on.
            index (int): the index in the memory segment.
        """
        # Your code goes here!
        # Note: each reference to "static i" appearing in the file Xxx.vm should
        # be translated to the assembly symbol "Xxx.i". In the subsequent
        # assembly process, the Hack assembler will allocate these symbolic
        # variables to the RAM, starting at address 16.
        if command not in {"C_PUSH", "C_POP"}:
            raise ValueError(f"invalid command: {command} {segment} {index}")

        if command == "C_POP" and segment == "constant":
            raise ValueError(
                f"cannot pop to constant segment: {command} {segment} {index}")

        if segment == "pointer" and index > 1:
            raise ValueError(f"invalid pointer index: {index}")

        symbol = {
            "static": f"{self.current_file}.{index}",
            "local": "LCL",
            "argument": "ARG",
            "this": "THIS",
            "that": "THAT",
            "temp": 5,
            "pointer": 3
        }

        self.write_comment(f"{command} {segment} {index}")

        if command == "C_PUSH":
            # load *segment[index] to D
            if segment == "constant":
                # simply load index to A
                self.output_stream.write(
                    f"\t@{index}\n"
                    "\tD=A\n"  # D = index
                )
            elif segment == "static":
                self.output_stream.write(
                    f"\t@{symbol[segment]}\n"
                    "\tD=M\n"
                )
            elif segment == "temp" or segment == "pointer":
                self.output_stream.write(
                    f"\t@{symbol[segment] + index}\n"
                    "\tD=M\n"
                )
            else:  # local, argument, this, that, static
                self.output_stream.write(
                    f"\t@{index}\n"
                    "\tD=A\n"
                    f"\t@{symbol[segment]}\n"
                    "\tA=D+M\n"
                    "\tD=M\n"
                )

            # push D to stack
            self.output_stream.write(
                "\t@SP\n"
                "\tA=M\n"  # A = SP
                "\tM=D\n"  # *SP = D
                "\t@SP\n"
                "\tM=M+1\n"  # SP++
            )

        else:  # command == "C_POP"
            # load address of segment[index] to D
            if segment == "static":
                self.output_stream.write(
                    f"\t@{symbol[segment]}\n"
                    "\tD=A\n"
                )
            elif segment == "temp" or segment == "pointer":
                self.output_stream.write(
                    f"\t@{symbol[segment] + index}\n"
                    "\tD=A\n"
                )
            else:  # local, argument, this, that, static
                self.output_stream.write(
                    f"\t@{index}\n"
                    "\tD=A\n"
                    f"\t@{symbol[segment]}\n"
                    "\tA=D+M\n"
                    "\tD=A\n"
                )

            # pop into segment[index]
            self.output_stream.write(
                "\t@R13\n"  # use R13 as a temp variable
                "\tM=D\n"  # R13 = address of segment[index]
                "\t@SP\n"
                "\tAM=M-1\n"  # SP--; A=SP
                "\tD=M\n"  # D = *SP
                "\t@R13\n"
                "\tA=M\n"  # A = segment[index] address
                "\tM=D\n"  # segment[index] = D
            )

    def write_label(self, label: str) -> None:
        """Writes assembly code that affects the label command.
        Let "Xxx.foo" be a function within the file Xxx.vm. The handling of
        each "label bar" command within "Xxx.foo" generates and injects the symbol
        "Xxx.foo$bar" into the assembly code stream.
        When translating "goto bar" and "if-goto bar" commands within "foo",
        the label "Xxx.foo$bar" must be used instead of "bar".

        Args:
            label (str): the label to write.
        """
        # This is irrelevant for project 7,
        # you will implement this in project 8!
        pass

    def write_goto(self, label: str) -> None:
        """Writes assembly code that affects the goto command.

        Args:
            label (str): the label to go to.
        """
        # This is irrelevant for project 7,
        # you will implement this in project 8!
        pass

    def write_if(self, label: str) -> None:
        """Writes assembly code that affects the if-goto command.

        Args:
            label (str): the label to go to.
        """
        # This is irrelevant for project 7,
        # you will implement this in project 8!
        pass

    def write_function(self, function_name: str, n_vars: int) -> None:
        """Writes assembly code that affects the function command.
        The handling of each "function Xxx.foo" command within the file Xxx.vm
        generates and injects a symbol "Xxx.foo" into the assembly code stream,
        that labels the entry-point to the function's code.
        In the subsequent assembly process, the assembler translates this
        symbol into the physical address where the function code starts.

        Args:
            function_name (str): the name of the function.
            n_vars (int): the number of local variables of the function.
        """
        # This is irrelevant for project 7,
        # you will implement this in project 8!
        # The pseudo-code of "function function_name n_vars" is:
        # (function_name)       // injects a function entry label into the code
        # repeat n_vars times:  // n_vars = number of local variables
        #   push constant 0     // initializes the local variables to 0
        pass

    def write_call(self, function_name: str, n_args: int) -> None:
        """Writes assembly code that affects the call command.
        Let "Xxx.foo" be a function within the file Xxx.vm.
        The handling of each "call" command within Xxx.foo's code generates and
        injects a symbol "Xxx.foo$ret.i" into the assembly code stream, where
        "i" is a running integer (one such symbol is generated for each "call"
        command within "Xxx.foo").
        This symbol is used to mark the return address within the caller's
        code. In the subsequent assembly process, the assembler translates this
        symbol into the physical memory address of the command immediately
        following the "call" command.

        Args:
            function_name (str): the name of the function to call.
            n_args (int): the number of arguments of the function.
        """
        # This is irrelevant for project 7,
        # you will implement this in project 8!
        # The pseudo-code of "call function_name n_args" is:
        # push return_address   // generates a label and pushes it to the stack
        # push LCL              // saves LCL of the caller
        # push ARG              // saves ARG of the caller
        # push THIS             // saves THIS of the caller
        # push THAT             // saves THAT of the caller
        # ARG = SP-5-n_args     // repositions ARG
        # LCL = SP              // repositions LCL
        # goto function_name    // transfers control to the callee
        # (return_address)      // injects the return address label into the code
        pass

    def write_return(self) -> None:
        """Writes assembly code that affects the return command."""
        # This is irrelevant for project 7,
        # you will implement this in project 8!
        # The pseudo-code of "return" is:
        # frame = LCL                   // frame is a temporary variable
        # return_address = *(frame-5)   // puts the return address in a temp var
        # *ARG = pop()                  // repositions the return value for the caller
        # SP = ARG + 1                  // repositions SP for the caller
        # THAT = *(frame-1)             // restores THAT for the caller
        # THIS = *(frame-2)             // restores THIS for the caller
        # ARG = *(frame-3)              // restores ARG for the caller
        # LCL = *(frame-4)              // restores LCL for the caller
        # goto return_address           // go to the return address
        pass

    def write_comment(self, comment: str) -> None:
        """Writes a comment line in the output assembly file.

        Args:
            comment (str): the comment to write.
        """
        self.output_stream.write(f"\n// {comment}\n")
